# AI SQL Functions at Scale — Best Practices

## Core Rules

1. **NEVER call AI functions in a subquery that loops row-by-row** — one LLM call per row = N calls.
2. **Use a single `CREATE TABLE AS SELECT` with the AI function inline** — Snowflake parallelizes automatically.
3. **For batching/aggregation use `AI_AGG`** — designed for aggregating AI results across groups.
4. **Pre-filter with `AI_FILTER` before heavier functions** — reduces tokens processed.
5. **Cache results**: write AI output to a column/table; don't recompute on every query.

---

## Pattern: Apply AI Function to Entire Table

```sql
-- Single scan, fully parallelized by Snowflake
CREATE OR REPLACE TABLE <output_table> AS
SELECT
  *,
  SNOWFLAKE.CORTEX.<FUNCTION>(<text_column>) AS <result_col>
FROM <source_table>
WHERE <text_column> IS NOT NULL;
```

### Examples by function

```sql
-- Sentiment analysis on all rows
CREATE OR REPLACE TABLE reviews_scored AS
SELECT *, SNOWFLAKE.CORTEX.SENTIMENT(review_text) AS sentiment_score
FROM customer_reviews;

-- Classification
CREATE OR REPLACE TABLE tickets_classified AS
SELECT *, AI_CLASSIFY(description, ['Bug', 'Feature', 'Question']) AS category
FROM support_tickets;

-- Summarization (expensive — pre-filter first)
CREATE OR REPLACE TABLE long_docs_summary AS
SELECT *, SNOWFLAKE.CORTEX.SUMMARIZE(content) AS summary
FROM documents
WHERE LENGTH(content) > 500;   -- skip short docs

-- Translation
CREATE OR REPLACE TABLE texts_translated AS
SELECT *, SNOWFLAKE.CORTEX.TRANSLATE(text_es, 'es', 'it') AS text_it
FROM source_texts;

-- Extraction
CREATE OR REPLACE TABLE invoices_extracted AS
SELECT *, AI_EXTRACT(body, ['total', 'vendor', 'date']) AS extracted
FROM invoices;
```

---

## Pattern: Pre-filter then Process (Cost Optimization)

```sql
-- Step 1: filter only relevant rows (cheap)
-- Step 2: apply heavy LLM only to filtered set
CREATE OR REPLACE TABLE complaints_analyzed AS
SELECT
  *,
  SNOWFLAKE.CORTEX.COMPLETE('mistral-large2',
    'Analiza esta queja e indica: causa raíz, urgencia (1-5), acción recomendada. Texto: ' || complaint_text
  ) AS analysis
FROM customer_feedback
WHERE AI_FILTER(complaint_text, 'Es una queja o reclamación grave');
-- → AI_FILTER is cheap; COMPLETE only runs on filtered rows
```

---

## Pattern: AI_AGG for Group-Level Insights

```sql
-- Single LLM call per group (not per row)
SELECT
  department,
  AI_AGG(feedback_text, 'Resume los principales problemas mencionados') AS dept_summary,
  COUNT(*) AS feedback_count
FROM employee_feedback
GROUP BY department;
```

---

## Pattern: Incremental Processing (New Rows Only)

```sql
-- Only process rows not yet scored
INSERT INTO reviews_scored
SELECT *, SNOWFLAKE.CORTEX.SENTIMENT(review_text) AS sentiment_score
FROM customer_reviews r
WHERE NOT EXISTS (
  SELECT 1 FROM reviews_scored s WHERE s.review_id = r.review_id
);
```

---

## Cost Estimations

| Function | Approx. tokens per row | Notes |
|----------|------------------------|-------|
| `SENTIMENT` | ~50-200 | Fast, cheap |
| `TRANSLATE` | ~100-500 | Scales with text length |
| `SUMMARIZE` | ~500-2000 | Medium cost |
| `AI_CLASSIFY` | ~100-300 | Cheap |
| `COMPLETE` (custom prompt) | ~200-5000 | Depends on prompt+response length |
| `AI_EXTRACT` | ~200-1000 | Depends on fields |

**Rule**: Always add `WHERE text_col IS NOT NULL AND LENGTH(text_col) > 10` to skip empty/trivial rows.

---

## Anti-patterns

```sql
-- ❌ NUNCA: llamar AI en un bucle o procedimiento fila a fila
DECLARE cur CURSOR FOR SELECT id, text FROM tabla;
FOR row IN cur DO
  CALL process_with_ai(row.text);  -- N llamadas LLM
END FOR;

-- ❌ NUNCA: recalcular en cada SELECT
SELECT *, SNOWFLAKE.CORTEX.SENTIMENT(text) FROM tabla;  -- si la tabla tiene 1M filas, 1M llamadas cada vez

-- ✅ CORRECTO: calcular una vez, guardar resultado
CREATE TABLE tabla_scored AS SELECT *, SNOWFLAKE.CORTEX.SENTIMENT(text) AS score FROM tabla;
-- Consultar siempre tabla_scored, no recalcular
```

# Streamlit in Snowflake (SiS) — Best Practices

> **Target version: `streamlit=1.35.0`** (warehouse runtime). Always pin this version in `environment.yml`.
> All code patterns in this file use only APIs available in 1.35.0. Never use post-1.35 features listed in the ❌ section below.

## Critical Differences vs Open-Source Streamlit

### Session & Connection
```python
# PORTABLE (warehouse + container)
conn = st.connection("snowflake")
session = conn.session()

# WAREHOUSE-ONLY — fails in container
from snowflake.snowpark.context import get_active_session
session = get_active_session()
```
Always use `st.connection("snowflake")` for portability.

### Owner's Rights Model
- App runs with **owner's** privileges, NOT the viewer's.
- Viewers cannot change role/database/warehouse.
- For viewer-specific data: use `CURRENT_USER()` in queries or row access policies.

### CSP — No External Code (Top Error Source)
**Blocked:** `<script src>`, `<link href>`, `@import url()`, `eval()`, CDN scripts.
**Allowed:** External images/media, Mapbox tiles.
Custom components loading CDN scripts will silently fail.

### Unsupported / Silent Failures
- `st.set_page_config(page_title=...)` — ignored. Title = STREAMLIT object name.
- `st.bokeh_chart` — not supported.
- Cross-session caching in warehouse runtime — session-scoped only.

---

## Streamlit 1.35.0 Feature Set

### ✅ Available in 1.35.0 — use freely

| Category | APIs |
|---|---|
| **NEW in 1.35** | `st.logo`, `st.dataframe(selection_mode=...)`, `st.plotly_chart(on_select=...)`, `st.altair_chart(on_select=...)`, `st.vega_lite_chart(on_select=...)` |
| Layout | `st.columns`, `st.tabs`, `st.expander`, `st.container(border=True)`, `st.popover`, `st.sidebar`, `st.empty` |
| Data display | `st.dataframe`, `st.data_editor`, `st.metric`, `st.table`, `st.json`, `st.column_config` |
| Charts | `st.altair_chart`, `st.plotly_chart`, `st.vega_lite_chart`, `st.bar_chart`, `st.line_chart`, `st.area_chart`, `st.scatter_chart`, `st.map`, `st.pydeck_chart` |
| Input widgets | `st.selectbox`, `st.multiselect`, `st.radio`, `st.checkbox`, `st.slider`, `st.text_input`, `st.text_area`, `st.number_input`, `st.date_input`, `st.time_input`, `st.button`, `st.form`, `st.file_uploader`, `st.download_button`, `st.color_picker`, `st.toggle` |
| Text | `st.title`, `st.header`, `st.subheader`, `st.markdown`, `st.caption`, `st.code`, `st.latex`, `st.divider` |
| Media | `st.image`, `st.video`, `st.audio` |
| Status | `st.spinner`, `st.progress`, `st.toast`, `st.balloons`, `st.error`, `st.warning`, `st.info`, `st.success` |
| State & flow | `st.session_state`, `st.cache_data`, `st.cache_resource`, `st.rerun`, `st.stop`, `st.query_params`, `st.fragment` |
| Chat | `st.chat_input`, `st.chat_message`, `st.write_stream` |
| Navigation (multipage) | `pages/` directory — filenames become pages. `st.page_link` with Material icons |
| Dialogs | `st.experimental_dialog` (experimental — use this, NOT `st.dialog`) |

### ❌ NOT available in 1.35.0 — never use

| API | Introduced in |
|---|---|
| `st.pills` | 1.37 |
| `st.segmented_control` | 1.37 |
| `st.feedback` | 1.38 |
| `st.html` | 1.39 |
| `st.navigation` / `st.Page` | 1.36 |
| `st.context` | 1.36 |
| `st.dialog` (GA, non-experimental) | 1.36 |
| `st.column_config` freeze columns | 1.41 |
| `st.button(type="tertiary")` | 1.41 |
| `st.metric(border=True)` | 1.41 |
| `baseRadius` in config.toml | 1.41 |

### Data Limits
- Single command → max **32 MB** to frontend (warehouse) / 200 MB (container). Paginate large results.

---

## Canonical App Structure

```
my_app/
├── .streamlit/config.toml      # Theme + sleep timer
├── streamlit_app.py            # Entrypoint — routing, inject_css()
├── styles.py                   # CSS injection (inject_css function)
├── queries.py                  # ALL data access — no st.* imports (testable)
├── cortex.py                   # Cortex AI helpers (optional)
├── components/                 # Reusable UI patterns
├── pages/                      # Multipage via pages/ directory (st.navigation not available in 1.35)
├── environment.yml             # Warehouse runtime deps (Conda)
└── pyproject.toml              # Container runtime deps (PyPI via EAI)
```

### Entrypoint Skeleton
```python
import streamlit as st
from styles import inject_css

st.set_page_config(layout="wide")
inject_css()

conn = st.connection("snowflake")
session = conn.session()
```

### Data Module (queries.py)
```python
# No st.* imports — fully testable with pytest
from snowflake.snowpark import Session

def get_kpis(session: Session, region: str) -> dict:
    df = session.sql(
        "SELECT metric, value, delta FROM kpi_view WHERE region = ?",
        params=[region]
    ).to_pandas()
    return {row["METRIC"]: (row["VALUE"], row["DELTA"]) for _, row in df.iterrows()}
```

---

## Cortex AI Integration

```python
# cortex.py
def cortex_complete(session, prompt: str, model: str = "snowflake-arctic") -> str:
    result = session.sql(
        "SELECT SNOWFLAKE.CORTEX.COMPLETE(?, ?) AS response",
        params=[model, prompt]
    ).collect()
    return result[0]["RESPONSE"]

def cortex_sentiment(session, text: str) -> float:
    result = session.sql(
        "SELECT SNOWFLAKE.CORTEX.SENTIMENT(?) AS score",
        params=[text]
    ).collect()
    return result[0]["SCORE"]
```

---

## Runtime Selection

| | Warehouse | Container |
|---|---|---|
| Session | `st.connection` or `get_active_session` | `st.connection` only |
| Cache | Session-scoped | Fully shared |
| Deps | `environment.yml` (Conda, snowflake channel) | `pyproject.toml` (PyPI + EAI) |
| Max message | 32 MB fixed | 200 MB configurable |
| `_snowflake` module | Available | NOT available |
| Custom components v2 | Inline HTML/JS only | Full asset dir |

---

## Styling (3 Layers)

### Layer 1: config.toml (Global)
```toml
# .streamlit/config.toml — compatible with 1.35.0
# NOTE: baseRadius not available until 1.41 — omit it
[theme]
base = "light"
primaryColor = "#29B5E8"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F4FAFE"
textColor = "#11567F"
[theme.sidebar]
backgroundColor = "#11567F"
textColor = "#FFFFFF"
primaryColor = "#29B5E8"
[snowflake]
streamlitSleepTimeoutMinutes = 15
```

### Layer 2: CSS Injection (styles.py)
```python
def inject_css():
    st.markdown("""<style>
    .block-container { padding-top: 2rem; max-width: 72rem; }
    #MainMenu, header, footer { visibility: hidden; }
    [data-testid="stMetric"] {
        background: var(--secondary-background-color);
        border: 1px solid rgba(0,0,0,0.05); border-radius: 0.75rem;
        padding: 1rem 1.25rem;
    }
    [data-testid="stMetricValue"] { font-size: 1.75rem !important; font-weight: 700 !important; }
    </style>""", unsafe_allow_html=True)
```
CSS variables: `var(--primary-color)`, `var(--background-color)`, `var(--secondary-background-color)`, `var(--text-color)`.

---

## Auto-Deploy Workflow (execute after writing .py files)

After writing all local files, deploy automatically in this sequence. No approval needed.

> **⚠️ NEVER use `PUT` to upload files** — `PUT` is not supported in this environment.
> **ALWAYS use `snow stage copy`** to upload files to Snowflake stages.

### Step 1: Resolve deployment parameters

Run this SQL to get active database, schema, and warehouse:
```sql
SELECT CURRENT_DATABASE() AS db, CURRENT_SCHEMA() AS schema, CURRENT_WAREHOUSE() AS wh;
```
Derive `APP_NAME` from the main .py filename (strip `.py`, replace `-` with `_`).
Derive `LOCAL_DIR` as the directory containing the .py files.

### Step 2: Create stage (if needed)

```sql
CREATE STAGE IF NOT EXISTS streamlit_apps
  ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE')
  COMMENT = 'Streamlit app files';
```

### Step 3: Upload files to stage

Use `snow stage copy` for each file in `LOCAL_DIR`:
```bash
snow stage copy "<LOCAL_DIR>/streamlit_app.py" @streamlit_apps/<APP_NAME>/ --overwrite
snow stage copy "<LOCAL_DIR>/styles.py"         @streamlit_apps/<APP_NAME>/ --overwrite
snow stage copy "<LOCAL_DIR>/queries.py"        @streamlit_apps/<APP_NAME>/ --overwrite
# Upload .streamlit/config.toml if present:
snow stage copy "<LOCAL_DIR>/.streamlit/config.toml" @streamlit_apps/<APP_NAME>/.streamlit/ --overwrite
```
Upload all `.py` files present in `LOCAL_DIR`. Skip files that don't exist.

### Step 4: Create the STREAMLIT object

```sql
CREATE OR REPLACE STREAMLIT <APP_NAME>
  FROM '@streamlit_apps/<APP_NAME>'
  MAIN_FILE = 'streamlit_app.py'
  QUERY_WAREHOUSE = '<WH>';
```

### Step 5: Get the app URL

```sql
SHOW STREAMLITS LIKE '<APP_NAME>';
```
Extract `url_id` from result. App URL pattern:
`https://<account>.snowflakecomputing.com/streamlit/apps/<url_id>`

Show the URL to the user so they can open the app immediately.

### Error handling

| Error | Fix |
|-------|-----|
| `PUT not supported in this environment` | Do NOT retry with `PUT`. Use `snow stage copy` (Step 3) |
| `File not found on stage` | Re-run Step 3 for missing file |
| `Insufficient privileges` | Ask user to grant `CREATE STREAMLIT ON SCHEMA` |
| `Warehouse not found` | Run `SHOW WAREHOUSES` and use an available one |

---

## Deployment SQL Reference

```sql
-- Warehouse (standard)
CREATE OR REPLACE STREAMLIT my_app
  FROM '@streamlit_apps/my_app'
  MAIN_FILE = 'streamlit_app.py'
  QUERY_WAREHOUSE = my_wh;

-- Container
CREATE OR REPLACE STREAMLIT my_app
  FROM '@streamlit_apps/my_app'
  MAIN_FILE = 'streamlit_app.py'
  RUNTIME_NAME = 'SYSTEM$ST_CONTAINER_RUNTIME_PY3_11'
  COMPUTE_POOL = my_compute_pool
  QUERY_WAREHOUSE = my_query_wh
  EXTERNAL_ACCESS_INTEGRATIONS = (pypi_eai);
```

```yaml
# environment.yml (warehouse — both fields required)
name: sf_env
channels:
  - snowflake
dependencies:
  - streamlit=1.35.0
  - snowflake-snowpark-python
  - pandas
```

---

## Common Pitfalls Checklist

- [ ] `PUT` to upload files → **not supported**, always use `snow stage copy <file> @<stage>/ --overwrite`
- [ ] External JS/CSS via CDN → blocked by CSP, silent failure
- [ ] Secrets in `secrets.toml` → use `_snowflake` module or SQL UDFs
- [ ] `st.dataframe` with >32 MB → paginate
- [ ] `st.set_page_config(page_title=...)` → silently ignored
- [ ] Missing `channels: - snowflake` in `environment.yml` → deps won't install
- [ ] Google Fonts `@import url()` → CSP blocked
- [ ] `_snowflake` in container runtime → not available
- [ ] `st.bokeh_chart` → not supported
- [ ] `st.navigation` / `st.Page` → not available in 1.35, use `pages/` directory
- [ ] `st.dialog` (non-experimental) → use `st.experimental_dialog` in 1.35
- [ ] `st.pills`, `st.segmented_control`, `st.feedback`, `st.html` → not available in 1.35
- [ ] `baseRadius` in config.toml → not available in 1.35 (introduced in 1.41)
- [ ] `st.button(type="tertiary")` → not available in 1.35

# Warehouse Scaling for ML on Many Rows

## Core Rule

Scale the warehouse to **LARGE** before any heavy ML operation and restore the original size immediately after. Never leave the warehouse at L permanently.

---

## Standard Scaling Workflow

Execute these steps in order, automatically:

### Step 1: Capture current warehouse and size

```sql
SELECT CURRENT_WAREHOUSE() AS wh, WAREHOUSE_SIZE
FROM INFORMATION_SCHEMA.WAREHOUSES
WHERE WAREHOUSE_NAME = CURRENT_WAREHOUSE();
```
Store `wh` and `WAREHOUSE_SIZE` to restore later.

### Step 2: Scale up to LARGE

```sql
ALTER WAREHOUSE <wh> SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;
```
`WAIT_FOR_COMPLETION = TRUE` ensures the warehouse is fully resized before the ML job starts.

### Step 3: Execute the ML operation

Run the ML query (see patterns below). Use `snowflake_sql_execute`.

### Step 4: Scale back to original size

```sql
ALTER WAREHOUSE <wh> SET WAREHOUSE_SIZE = '<ORIGINAL_SIZE>';
```
Always restore even if Step 3 fails — wrap in a try/finally pattern if using Python.

---

## ML Patterns (run at Step 3)

### Snowflake ML Functions — Classification

```sql
CREATE OR REPLACE TABLE <output_table> AS
SELECT
  *,
  SNOWFLAKE.ML.CLASSIFY(
    <feature_col_1>, <feature_col_2>, -- ...
    <label_col>
  ) AS prediction
FROM <source_table>;
```

### Snowflake ML Functions — Forecast

```sql
CREATE OR REPLACE TABLE <forecast_output> AS
SELECT *
FROM TABLE(
  SNOWFLAKE.ML.FORECAST(
    INPUT_DATA => SYSTEM$REFERENCE('TABLE', '<source_table>'),
    TIMESTAMP_COLNAME => '<date_col>',
    TARGET_COLNAME => '<target_col>',
    SERIES_COLNAME => '<series_col>',     -- optional
    FORECASTING_PERIODS => <N>
  )
);
```

### Snowpark ML — Batch Scoring (Python)

```python
from snowflake.ml.modeling.pipeline import Pipeline
from snowflake.snowpark import Session
import os

session = Session.builder.config(
    "connection_name", os.getenv("SNOWFLAKE_CONNECTION_NAME") or "snowhouse"
).create()

# Scale up
session.sql("ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE").collect()

try:
    df = session.table("<source_table>")
    # ... load model and score ...
    predictions = model.predict(df)
    predictions.write.save_as_table("<output_table>", mode="overwrite")
finally:
    # Always restore
    session.sql("ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = '<ORIGINAL_SIZE>'").collect()
```

### Cortex AI on Many Rows (also benefits from L warehouse)

```sql
-- Scale up first, then:
CREATE OR REPLACE TABLE <output_table> AS
SELECT *, SNOWFLAKE.CORTEX.COMPLETE('mistral-large2', <prompt_col>) AS result
FROM <source_table>;
```

### Model Registry — Batch Inference (recommended pattern)

Train once, register, call via SQL on any table. No Python needed at inference time.

```python
# --- TRAINING (run once) ---
from snowflake.ml.modeling.xgboost import XGBClassifier
from snowflake.ml.registry import Registry
from snowflake.snowpark import Session
import os

session = Session.builder.config(
    "connection_name", os.getenv("SNOWFLAKE_CONNECTION_NAME") or "snowhouse"
).create()

# Scale up for training
session.sql("ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE").collect()

try:
    train_df = session.table("<train_table>")
    model = XGBClassifier(
        input_cols=["<feat1>", "<feat2>", "<feat3>"],
        label_cols=["<label_col>"],
        output_cols=["prediction"]
    )
    model.fit(train_df)

    # Register in Model Registry
    reg = Registry(session=session, database_name="<db>", schema_name="<schema>")
    mv = reg.log_model(
        model,
        model_name="<model_name>",
        version_name="v1",
        sample_input_data=train_df.limit(10)
    )
finally:
    session.sql("ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'XSMALL'").collect()
```

```sql
-- --- INFERENCE via SQL (scale up → score → restore) ---
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;

CREATE OR REPLACE TABLE <inference_output> AS
SELECT input.*, pred.prediction
FROM <inference_table> AS input,
     TABLE(<db>.<schema>.<model_name>!PREDICT(
       INPUT_DATA => input,
       PARTITION_COLUMN => '<partition_col>'   -- optional, for parallelism
     )) AS pred;

ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'XSMALL';
```

### Model Registry — Online Inference (row by row, e.g. from Streamlit)

```python
# In Streamlit or stored procedure — no warehouse scaling needed for single rows
reg = Registry(session=session, database_name="<db>", schema_name="<schema>")
mv = reg.get_model("<model_name>").version("v1")

input_df = session.create_dataframe([[val1, val2, val3]], schema=["<feat1>", "<feat2>", "<feat3>"])
result = mv.run(input_df, function_name="predict").to_pandas()
prediction = result["PREDICTION"].iloc[0]
```

### Snowflake ML — Anomaly Detection via Model Object (`!DETECT_ANOMALIES`)

```sql
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;

CREATE OR REPLACE TEMPORARY TABLE <output_table> AS
SELECT * FROM TABLE(
  <db>.<schema>.<model_name>!DETECT_ANOMALIES(
    INPUT_DATA => SYSTEM$QUERY_REFERENCE('
      SELECT <series_col>::VARIANT AS serie,
             <timestamp_col>::TIMESTAMP_NTZ AS fecha,
             <target_col>
      FROM <source_table>
      WHERE <timestamp_col> >= DATEADD(''month'', -3, CURRENT_DATE())
    '),
    SERIES_COLNAME    => ''SERIE'',
    TIMESTAMP_COLNAME => ''FECHA'',
    TARGET_COLNAME    => ''<TARGET_COL>'',
    CONFIG_OBJECT     => {''prediction_interval'': 0.99}
  )
);

ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'XSMALL';
```

**Notas importantes:**
- Las comillas simples dentro de `SYSTEM$QUERY_REFERENCE` deben escaparse como `''` (doble comilla simple).
- `SERIES_COLNAME`, `TIMESTAMP_COLNAME`, `TARGET_COLNAME` deben pasarse también con `''` porque son strings dentro de la llamada al modelo.
- `CONFIG_OBJECT` acepta `prediction_interval` (0.0–1.0) para controlar sensibilidad: valores altos (0.99) = menos falsos positivos.
- Usar `TEMPORARY TABLE` para resultados intermedios — se elimina automáticamente al final de la sesión.

**Ejemplo real (consumos de agua):**
```sql
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;

CREATE OR REPLACE TEMPORARY TABLE ANOMALIAS_CONSUMO_DB.PUBLIC.TMP_ANOM_CONSUMO AS
SELECT * FROM TABLE(
  ANOMALIAS_CONSUMO_DB.PUBLIC.DETECTOR_ANOMALIAS_CONSUMO!DETECT_ANOMALIES(
    INPUT_DATA => SYSTEM$QUERY_REFERENCE('
      SELECT abonado_id::VARIANT AS serie, fecha::TIMESTAMP_NTZ AS fecha, consumo_litros, consumo_nocturno_litros
      FROM ANOMALIAS_CONSUMO_DB.PUBLIC.CONSUMOS
      WHERE fecha >= DATEADD(''month'', -3, CURRENT_DATE())
    '),
    SERIES_COLNAME    => ''SERIE'',
    TIMESTAMP_COLNAME => ''FECHA'',
    TARGET_COLNAME    => ''CONSUMO_LITROS'',
    CONFIG_OBJECT     => {''prediction_interval'': 0.99}
  )
);

ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'XSMALL';
```

```sql
-- No model training needed — use for text classification at inference time
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;

CREATE OR REPLACE TABLE <inference_output> AS
SELECT
  *,
  SNOWFLAKE.CORTEX.CLASSIFY_TEXT(<text_col>, ['<class1>', '<class2>', '<class3>']) AS predicted_class,
  SNOWFLAKE.CORTEX.SENTIMENT(<text_col>) AS sentiment_score
FROM <inference_table>;

ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE()) SET WAREHOUSE_SIZE = 'XSMALL';
```

---

## When to Use Each Size

| Scenario | Recommended size |
|---|---|
| < 100K rows, simple AI functions | XSMALL / SMALL |
| 100K–1M rows, AI functions | MEDIUM |
| > 1M rows, AI functions | **LARGE** |
| ML training (ML.CLASSIFY, Snowpark ML) | **LARGE** |
| ML.FORECAST on long time series | **LARGE** |
| Anomaly detection (`!DETECT_ANOMALIES`) | **LARGE** |
| Online inference (single row, Streamlit) | XSMALL — no scaling needed |

---

## Full Example: Scale → ML → Restore

```sql
-- Step 1: Note original size (XSMALL assumed if unknown)
-- Step 2: Scale up
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'LARGE' WAIT_FOR_COMPLETION = TRUE;

-- Step 3: ML operation
CREATE OR REPLACE TABLE scored_customers AS
SELECT
  customer_id,
  SNOWFLAKE.ML.CLASSIFY(age, income, tenure, product_count, 'churn') AS churn_prediction
FROM customers
WHERE active = TRUE;

-- Step 4: Restore
ALTER WAREHOUSE IDENTIFIER(CURRENT_WAREHOUSE())
  SET WAREHOUSE_SIZE = 'XSMALL';

-- Verify
SELECT COUNT(*), COUNT(churn_prediction) FROM scored_customers;
```

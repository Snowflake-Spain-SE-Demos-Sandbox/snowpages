# Data Generation Best Practices

## Core Rules

1. **NEVER use INSERT row-by-row** — creates N transactions, slow, expensive.
2. **ALWAYS use `TABLE(GENERATOR(rowcount => N))`** with `CREATE TABLE AS SELECT`.
3. **Use `MOD(ABS(RANDOM()), N)` for categorical columns** — deterministic, vectorized.
4. **Define a `textos` CTE with VALUES** for realistic text — join instead of calling CORTEX per row.

---

## Standard Template

```sql
CREATE OR REPLACE TABLE <table_name> AS
WITH base AS (
  SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4())              AS <id_col>,
    DATEADD('day', -UNIFORM(0,365,RANDOM()), CURRENT_DATE()) AS <date_col>,
    UNIFORM(<min>, <max>, RANDOM())                  AS <numeric_col>,
    CASE MOD(ABS(RANDOM()), <N>)
      WHEN 0 THEN '<val1>' WHEN 1 THEN '<val2>' -- ...
      ELSE '<valN>'
    END AS <category_col>
  FROM TABLE(GENERATOR(rowcount => <N>))
),
textos AS (
  SELECT column1 AS tipo, column2 AS texto FROM (VALUES
    ('<cat1>', '<texto realista de 50-150 palabras para cat1>'),
    ('<cat2>', '<texto realista para cat2>'),
    ('<cat3>', '<texto realista para cat3>')
  )
)
SELECT b.*, t.texto AS <text_col>
FROM base b
JOIN textos t ON t.tipo = b.<category_col>;
```

---

## Useful Functions

| Necesidad | Función |
|-----------|---------|
| ID secuencial | `ROW_NUMBER() OVER (ORDER BY SEQ4())` |
| Entero aleatorio en rango | `UNIFORM(min, max, RANDOM())` |
| Float aleatorio | `UNIFORM(0.0::FLOAT, 1.0::FLOAT, RANDOM())` |
| Fecha aleatoria (últimos N días) | `DATEADD('day', -UNIFORM(0,N,RANDOM()), CURRENT_DATE())` |
| Categoría aleatoria | `CASE MOD(ABS(RANDOM()), N) WHEN 0 THEN '...' ...` |
| String aleatoria (no semántica) | `RANDSTR(length, RANDOM())` |
| Número de fila | `SEQ4()` |

---

## Example: partes_trabajo (500 rows)

```sql
CREATE OR REPLACE TABLE partes_trabajo AS
WITH base AS (
  SELECT
    ROW_NUMBER() OVER (ORDER BY SEQ4())                          AS parte_id,
    DATEADD('day', -UNIFORM(0,730,RANDOM()), CURRENT_DATE())     AS fecha,
    UNIFORM(1,20,RANDOM())                                        AS operario_id,
    CASE MOD(ABS(RANDOM()),5)
      WHEN 0 THEN 'Red_Norte' WHEN 1 THEN 'Red_Sur'
      WHEN 2 THEN 'ETAP'      WHEN 3 THEN 'EDAR' ELSE 'Depositos'
    END AS zona,
    CASE MOD(ABS(RANDOM()),5)
      WHEN 0 THEN 'Averia' WHEN 1 THEN 'Fuga'
      WHEN 2 THEN 'Calidad' WHEN 3 THEN 'Vandalismo' ELSE 'Obstruccion'
    END AS tipo_real,
    CASE MOD(ABS(RANDOM()),4)
      WHEN 0 THEN 'Baja' WHEN 1 THEN 'Media'
      WHEN 2 THEN 'Alta' ELSE 'Critica'
    END AS urgencia_real
  FROM TABLE(GENERATOR(rowcount => 500))
),
textos AS (
  SELECT column1 AS tipo, column2 AS txt FROM (VALUES
    ('Averia',      'Se detecta avería en grupo de presión. Inspección visual, sustitución de rodamiento, prueba en vacío. Sistema restaurado.'),
    ('Fuga',        'Localización de fuga en tubería DN200. Corte de suministro, reparación con collarín. Prueba estanqueidad 8 bar OK.'),
    ('Calidad',     'Alarma de turbidez. Muestras a laboratorio, ajuste de coagulante. Parámetros dentro de RD 3/2023 tras 2h.'),
    ('Vandalismo',  'Apertura forzada de arqueta. Reposición de candado reforzado. Sin afección al suministro. Denuncia presentada.'),
    ('Obstruccion', 'Obstrucción en colector 315mm por grasas. Limpieza con cuba alta presión. Sección libre al 100% verificada.')
  )
)
SELECT b.*, t.txt AS texto_observaciones
FROM base b JOIN textos t ON t.tipo = b.tipo_real;
```

---

## Anti-patterns to Avoid

```sql
-- ❌ NUNCA: INSERTs individuales
INSERT INTO tabla VALUES (1, 'Averia', ...);
INSERT INTO tabla VALUES (2, 'Fuga', ...);
-- ... 500 veces

-- ❌ NUNCA: CORTEX.COMPLETE por fila para texto descriptivo
SELECT SNOWFLAKE.CORTEX.COMPLETE('mistral-large2', 'Genera texto para ' || tipo) FROM base;
-- → 500 llamadas LLM = muy caro y lento

-- ✅ CORRECTO: CTE VALUES + JOIN
-- → 1 sola query, coste mínimo, velocidad máxima
```
